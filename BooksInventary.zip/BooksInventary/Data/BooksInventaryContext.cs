﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using BooksInventary.Model;

namespace BooksInventary.Data
{
    public class BooksInventaryContext : DbContext
    {
        public BooksInventaryContext (DbContextOptions<BooksInventaryContext> options)
            : base(options)
        {
        }

        public DbSet<BooksInventary.Model.book> book { get; set; } = default!;
    }
}
